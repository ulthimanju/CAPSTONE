from uuid import UUID
from fastapi import APIRouter, Depends, Request
from sqlalchemy import select, or_, func
from sqlalchemy.ext.asyncio import AsyncSession
import uuid

from app.api.dependencies.auth import get_current_user_id
from app.api.dependencies.database import (
    get_member_repository,
    get_invitation_repository,
    get_activity_repository,
    get_db,
)
from app.domain.repositories.member_repository import MemberRepository
from app.domain.repositories.invitation_repository import InvitationRepository
from app.domain.repositories.activity_repository import ActivityRepository
from app.schemas.invitation import InvitationResponse
from app.application.use_cases.accept_invitation import AcceptInvitationUseCase
from app.application.use_cases.reject_invitation import RejectInvitationUseCase
from app.infrastructure.database.models import WorkspaceInvitationModel, WorkspaceModel

router = APIRouter(prefix="/invitations", tags=["Invitations"])


@router.get("/pending")
async def list_pending_invitations(
    request: Request,
    user_id: UUID = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    user_email = request.headers.get("x-user-email") or request.headers.get("X-User-Email")

    conditions = [WorkspaceInvitationModel.invited_user_id == user_id]

    if user_email:
        clean_email = user_email.lower().strip()
        prefix = clean_email.split("@")[0]
        conditions.append(func.lower(WorkspaceInvitationModel.invited_email) == clean_email)
        if len(prefix) > 2:
            conditions.append(func.lower(WorkspaceInvitationModel.invited_email).like(f"{prefix}@%"))
    else:
        # Fallback: if header is missing, include all pending email invitations
        conditions.append(WorkspaceInvitationModel.invited_email.isnot(None))

    stmt = (
        select(WorkspaceInvitationModel, WorkspaceModel.name.label("workspace_name"))
        .join(WorkspaceModel, WorkspaceInvitationModel.workspace_id == WorkspaceModel.id)
        .where(
            or_(*conditions),
            WorkspaceInvitationModel.status == "PENDING",
        )
    )
    res = await db.execute(stmt)
    invites = []
    for inv, ws_name in res.all():
        invites.append({
            "id": str(inv.id),
            "workspace_id": str(inv.workspace_id),
            "workspace_name": ws_name,
            "invited_by": str(inv.invited_by),
            "invited_email": inv.invited_email,
            "status": inv.status,
            "expires_at": inv.expires_at.isoformat() if inv.expires_at else None,
            "created_at": inv.created_at.isoformat() if inv.created_at else None,
        })
    return invites


@router.post("/{invitation_id}/accept", response_model=InvitationResponse)
async def accept_invitation(
    invitation_id: UUID,
    request: Request,
    user_id: UUID = Depends(get_current_user_id),
    inv_repo: InvitationRepository = Depends(get_invitation_repository),
    mem_repo: MemberRepository = Depends(get_member_repository),
    act_repo: ActivityRepository = Depends(get_activity_repository),
):
    user_email = request.headers.get("x-user-email") or request.headers.get("X-User-Email")
    use_case = AcceptInvitationUseCase(inv_repo, mem_repo, act_repo)
    return await use_case.execute(invitation_id, user_id, user_email)


@router.post("/{invitation_id}/reject", response_model=InvitationResponse)
async def reject_invitation(
    invitation_id: UUID,
    request: Request,
    user_id: UUID = Depends(get_current_user_id),
    inv_repo: InvitationRepository = Depends(get_invitation_repository),
):
    user_email = request.headers.get("x-user-email") or request.headers.get("X-User-Email")
    use_case = RejectInvitationUseCase(inv_repo)
    return await use_case.execute(invitation_id, user_id, user_email)
