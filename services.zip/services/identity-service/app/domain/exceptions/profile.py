class ProfileNotFoundError(Exception):
    pass
